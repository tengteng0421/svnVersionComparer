package org.tmatesoft.svn.core.wc2.admin;

import org.tmatesoft.svn.core.wc2.SvnOperationFactory;

public class SvnRepositoryGetYoungest extends SvnRepositoryOperation<Long> {
    
    public SvnRepositoryGetYoungest(SvnOperationFactory factory) {
        super(factory);
    }

}
